# 🧵 Silk Programming Language

**Simple • Intuitive • Lightweight • Keen**

Silk — это новый язык программирования с чистым синтаксисом, вдохновлённый лучшими идеями Python (простота), Go (ясность) и Rust (безопасность).

## Quick Start

```bash
# Интерактивный режим (REPL)
python silk.py

# Запуск файла
python silk.py examples/demo.silk
python silk.py examples/medical.silk
```

## Синтаксис

### Переменные
```
let name = "Temur"          // иммутабельная (нельзя менять)
let mut count = 0            // мутабельная (можно менять)
count = count + 1            // OK
// name = "other"            // ОШИБКА — иммутабельна!
```

### Типы данных
```
42, 3.14                     // числа (int, float)
"hello"                      // строки
true, false                  // логические
[1, 2, 3]                    // массивы
null                         // пусто
```

### Функции
```
fn add(a: int, b: int) -> int {
    return a + b
}

fn greet(name: str) {
    print("Hello, " + name)
}
```

### Условия
```
if score >= 90 {
    print("Excellent!")
} elif score >= 70 {
    print("Good")
} else {
    print("Keep trying")
}
```

### Циклы
```
// For loop
for i in range(10) {
    print(i)
}

for item in [1, 2, 3] {
    print(item)
}

// While loop
let mut x = 0
while x < 10 {
    x += 1
}
```

### Строки
```
let s = "Hello World"
s.upper()                    // "HELLO WORLD"
s.lower()                    // "hello world"
s.length                     // 11
s.starts_with("Hello")       // true
s.replace("World", "Silk")   // "Hello Silk"
```

### Массивы
```
let mut arr = [1, 2, 3]
push(arr, 4)                 // [1, 2, 3, 4]
pop(arr)                     // 4
sort(arr)                    // [1, 2, 3]
reverse(arr)                 // [3, 2, 1]
len(arr)                     // 3
```

### Функции высшего порядка
```
fn double(x: int) -> int { return x * 2 }
fn is_even(x: int) -> bool { return x % 2 == 0 }

map(double, [1, 2, 3])      // [2, 4, 6]
filter(is_even, [1, 2, 3])  // [2]
```

## Встроенные функции

| Категория | Функции |
|-----------|---------|
| **I/O** | `print()`, `input()` |
| **Типы** | `type()`, `str()`, `int()`, `float()`, `bool()` |
| **Коллекции** | `len()`, `range()`, `push()`, `pop()`, `sort()`, `reverse()`, `slice()` |
| **Функциональные** | `map()`, `filter()`, `join()`, `split()`, `contains()` |
| **Математика** | `abs()`, `round()`, `min()`, `max()`, `sum()`, `sqrt()`, `pow()`, `log()`, `sin()`, `cos()`, `pi()` |
| **Статистика** | `mean()`, `median()`, `stdev()` |
| **Медицина** 🩺 | `bmi()`, `bsa()`, `dose_per_kg()`, `ideal_body_weight()`, `fahrenheit_to_celsius()`, `celsius_to_fahrenheit()` |

## Медицинские функции

```
// BMI (индекс массы тела)
bmi(70.0, 1.75)                      // 22.86

// BSA (площадь поверхности тела, Du Bois)
bsa(70.0, 175.0)                     // 1.85 m²

// Дозировка по весу
dose_per_kg(15.0, 25.0)              // 375.0 mg

// Идеальная масса тела
ideal_body_weight(175.0, true)        // 70.6 kg

// Конвертация температуры
celsius_to_fahrenheit(37.0)           // 98.6
fahrenheit_to_celsius(98.6)           // 37.0

// Статистика
mean([36.6, 36.8, 37.1])             // 36.8333
median([36.6, 36.8, 37.1])           // 36.8
stdev([36.6, 36.8, 37.1])            // 0.2517
```

## Особенности языка

- 🔒 **Иммутабельность по умолчанию** — переменные нельзя менять без `mut` (как в Rust)
- 🧹 **Чистый синтаксис** — минимум шума, максимум читаемости
- 🩺 **Медицинские функции** — встроенные расчёты для педиатрии
- 📊 **Статистика** — mean, median, stdev из коробки
- 🔄 **Функции высшего порядка** — map, filter для функционального стиля
- 💬 **Комментарии** — `//` однострочные, `/* */` блочные

## Расширение файлов

`.silk` — рекомендуемое расширение для файлов Silk

---
*Created by Temur Turayev | TashPMI | 2026*
